

import React from 'react';
import {render} from 'react-dom';

// JUST FOR TEST
import AwesomeComponent from './test/AwesomeComponent.jsx';
import Calculator from './test/Calculator.jsx';
import WelcomeCompa from './test/WelcomeComp.jsx';
import Clock from './test/Clock.jsx';
import Toggle from './test/Toggle.jsx';

// Todo list component
import Todo from './todo/Todo.jsx';

import Style from './../sass/main.scss';

class App extends React.Component {

  render () {
    return (
      <div>
        <Todo />
      </div>
    );
  }

}

/*
 <p> Hello React!</p>
 <WelcomeCompa name="Sara" />
 <hr />
 <AwesomeComponent />
 <hr />
 <Calculator />
 <hr />
 <Clock enable={true} />
 <Toggle />
 <hr />
 */

render(<App/>, document.getElementById('contentSection'));
