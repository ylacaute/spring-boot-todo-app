
import React from 'react';

class TodoFilter {}
TodoFilter.SHOW_ALL = "SHOW_ALL";
TodoFilter.SHOW_ACTIVE = "SHOW_ACTIVE";
TodoFilter.SHOW_COMPLETED = "SHOW_COMPLETED";

export default TodoFilter;
