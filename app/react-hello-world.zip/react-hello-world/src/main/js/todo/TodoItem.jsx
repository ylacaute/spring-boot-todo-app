import React from 'react';

class TodoItem extends React.Component {

  constructor(props) {
    super(props);
    console.log("WTF !!! isDone : " + props.isDone);
  }

  deleteItem(event) {
    // delegating check changes to the someone else
    this.props.deleteItem(this, event);
  }

  checkItem(event) {
    // delegating check changes to the someone else
    this.props.checkItem(this, event);
  }

  render() {
    console.log("render ITEM --- isDone : " + this.props.isDone);
    let className = "toto-item";
    if (this.props.isDone == true) {
      className = className + " completed";
    }
    return (
      <li className={className}>
        <input type="checkbox"
               checked={this.props.isDone}
               onChange={this.checkItem.bind(this)}/>
        <span>{this.props.text}</span>
        <input className="edit" type="text" defaultValue={this.props.text} />
        <button className="destroy"
                onClick={this.deleteItem.bind(this)} />
      </li>
    )
  }

}

TodoItem.propTypes = {
  checkItem : React.PropTypes.func.isRequired,
  deleteItem : React.PropTypes.func.isRequired,
  isDone : React.PropTypes.bool.isRequired,
  text : React.PropTypes.string.isRequired
}


export default TodoItem;
