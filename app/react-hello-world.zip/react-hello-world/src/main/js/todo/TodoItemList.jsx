import React from 'react';
import TodoItem from './TodoItem.jsx';

class TodoItemList extends React.Component {

  constructor(props) {
    super(props);
    /*this.state = {
      todoItems: props.todoItems
    };*/
  }

  deleteItem(todoItem, event) {
    // delegating check changes to the someone else
    this.props.deleteItem(todoItem, event);
  }

  checkItem(todoItem, event) {
    // delegating check changes to the someone else
    console.log("TodoItemList ON CHECK");
    this.props.checkItem(todoItem, event);
  }

  render() {
    return (
      <ul className="todo-body">
        {this.props.todoItems.map((todoItem, index) => {
          return <TodoItem key={todoItem.id}
                           {...todoItem}
                           index={todoItem.id}
                           checkItem={this.checkItem.bind(this)}
                           deleteItem={this.deleteItem.bind(this)}/>;
        })}
      </ul>
    );
  }
}

TodoItemList.propTypes = {
  //todoItems : React.PropTypes.array.todoItems,
  checkItem : React.PropTypes.func.isRequired,
  deleteItem : React.PropTypes.func.isRequired
}

export default TodoItemList;
