import React from 'react';
import TodoItemList from './TodoItemList.jsx';

const TODO_STORAGE = "todos17";
const TODO_COUNTER_STORAGE = "todoCounter17";

class TodoFilter {}
TodoFilter.SHOW_ALL = "SHOW_ALL";
TodoFilter.SHOW_ACTIVE = "SHOW_ACTIVE";
TodoFilter.SHOW_COMPLETED = "SHOW_COMPLETED";

class Todo extends React.Component {

  constructor(props) {
    super(props);
    let todoItems = [];//sessionStorage.getItem(TODO_STORAGE);
    let todoItemIdCounter = 0//sessionStorage.getItem(TODO_COUNTER_STORAGE);
    /*
    if (todoItems === null) {
      todoItems = [];
      todoItemIdCounter = 0;
    } else {
      todoItems = JSON.parse(this.todoItems);
      todoItemIdCounter = parseInt(todoItemIdCounter);
    }
    */
    this.state = {
      todoItems: todoItems,
      todoItemIdCounter: todoItemIdCounter,
      isAllChecked: false,
      filter: TodoFilter.SHOW_ALL
    };
  }

  componentWillUnmount() {
    sessionStorage.removeItem(TODO_STORAGE);
  }

  isAllChecked(todoItems) {
    let isAllChecked = false;
    if (todoItems.every((todoItem) => todoItem.isDone)) {
      isAllChecked = true;
    }
    return isAllChecked;
  }

  updateAllChecked() {
    let isAllChecked = this.isAllChecked(this.state.todoItems);
    if (this.state.isAllChecked != isAllChecked) {
      this.setState({isAllChecked: isAllChecked});
    }
  }

  handlerKeyUp(event) {
    if (event.keyCode === 13) {
      let value = event.target.value;
      if (!value) return false;
      let newTodoItem = {
        id: this.getNextTodoItemid(),
        text: value,
        isDone: false
      };
      event.target.value = "";
      this.addItem(newTodoItem);
    }
  }

  getNextTodoItemid() {
    let nextId = this.state.todoItemIdCounter + 1;
    console.log("nextid = " + nextId);
    this.setState({todoItemIdCounter: nextId});
    //sessionStorage.setItem(TODO_COUNTER_STORAGE, nextId);
    return nextId;
  }

  addItem(todoItem) {
    console.log("Add todoItem : ", todoItem);
    this.state.todoItems.push(todoItem);
    this.setState({todoItems: this.state.todoItems});
    //sessionStorage.setItem(TODO_STORAGE, JSON.stringify(this.state.todoItems));
    this.updateAllChecked();
  }

  checkItem(todoItem) {
    console.log("TODO ON CHECK");
    let isDone = this.state.todoItems[todoItem.props.index].isDone;
    console.log("Changing checked state of itemId=" + todoItem.props.id + " to " + isDone);
    this.state.todoItems[todoItem.props.index].isDone = !isDone;
    this.setState(this.state);
    this.updateAllChecked();
  }

  deleteItem(todoItem) {
    console.log("Deleting itemId=" + todoItem.props.id);
    this.state.todoItems.splice(todoItem.props.index, 1);
    this.setState({todoItems: this.state.todoItems});
    //sessionStorage.setItem(TODO_STORAGE, JSON.stringify(this.state.todoItems));
  }

  deleteDoneItems() {
    let notDoneItems = this.state.todoItems.filter(item => !item.isDone);
    console.log("notDoneItems.legth :" + notDoneItems.length);
    this.setState({
      todoItems: notDoneItems,
      isAllChecked: false
    });
    //sessionStorage.setItem(TODO_STORAGE, JSON.stringify(notDoneItems));
  }

  checkAllItems() {
    console.log("isAllChecked : " + this.state.isAllChecked);
    let isAllChecked = !this.state.isAllChecked;
    let todoItems = this.state.todoItems.map((todo) => {
      todo.isDone = isAllChecked;
      return todo;
    });
    this.setState({todoItems: todoItems, isAllChecked: isAllChecked});
  }

  filterTodo(filter) {
    console.log("filter todo (filter = " + filter + ")");
    let todos = this.state.todoItems;
    switch (filter) {
      case TodoFilter.SHOW_ALL:
        return todos;
      case TodoFilter.SHOW_ACTIVE:
        return todos.filter(t => !t.isDone);
      case TodoFilter.SHOW_COMPLETED:
        return todos.filter(t => t.isDone);
    }
  }

  displayAll() {
    this.setState({filter: TodoFilter.SHOW_ALL});
    console.log("all");
  }

  displayActive() {
    this.setState({filter: TodoFilter.SHOW_ACTIVE});
    console.log("active");
  }

  displayCompleted() {
    this.setState({filter: TodoFilter.SHOW_COMPLETED});
    console.log("completed");
  }

  renderHeader() {
    return (
      <div className="todo-header">
        <h1>Your Todo list</h1>
        <input type="checkbox"
               checked={this.state.isAllChecked}
               onChange={this.checkAllItems.bind(this)}/>
        <input type="text"
               onKeyUp={this.handlerKeyUp.bind(this)}
               placeholder="what's your task ?"/>
      </div>
    )
  }

  renderBody() {
    let todoItems = this.filterTodo(this.state.filter);
    console.log("itemsToDisplay : ", todoItems);
    return (
      <TodoItemList todoItems={todoItems}
                    checkItem={this.checkItem.bind(this)}
                    deleteItem={this.deleteItem.bind(this)}/>
    );
    return <p>FUCK</p>;
  }

  renderFooter() {
    let filter = this.state.filter;
    let todoCount = this.state.todoItems.length || 0;
    let todoDoneCount = this.state.todoItems.filter((todo) => todo.isDone).length || 0;
    let deleteDoneBtn;
    let allClassName = filter == TodoFilter.SHOW_ALL ? "active" : "";
    let activeClassName = filter == TodoFilter.SHOW_ACTIVE ? "active" : "";
    let completedClassName = filter == TodoFilter.SHOW_COMPLETED ? "active" : "";

    if (this.state.isAllChecked) {
      deleteDoneBtn = <button onClick={this.deleteDoneItems.bind(this)}>Delete done</button>;
    }
    return (
      <div className="todo-footer">
        <ul className="todo-filter">
          <li className={allClassName}>
            <a href="#filter=All"
               onClick={this.displayAll.bind(this)}>All</a></li>
          <li className={activeClassName}>
            <a href="#filter=Active"
               onClick={this.displayActive.bind(this)}>Active</a></li>
          <li className={completedClassName}>
            <a href="#filter=Completed"
               onClick={this.displayCompleted.bind(this)}>Completed</a></li>
        </ul>
        {deleteDoneBtn}
      </div>
    )
  }

  render() {
    return (
      <div className="todo">
        {this.renderHeader()}
        {this.renderBody()}
        {this.renderFooter()}
      </div>
    )
  }

}

export default Todo;
